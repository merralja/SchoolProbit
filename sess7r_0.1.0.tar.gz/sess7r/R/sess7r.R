#' sess7r: A package with a minimum example of package creation.
#'
#' This package is an exercise in package creation using
#' R studio. The package will hopefully include a sample
#' function and a sample dataset with their respective
#' documentation, though the last time I tried this it
#' screwed up miserably.
#'
#' @docType package
#' @name sess7r
#' @author John Merrall, McMaster University \email{merralja@@mcmaster.ca}
#' @references \url{https://github.com/merralja/SchoolProbit}
NULL
