## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ------------------------------------------------------------------------
#setwd("C:/Users/me/Documents/GitHub/SchoolProbit/sess7r/")

## ------------------------------------------------------------------------
library(sess7r)
library(ggplot2)
library(tmap)

## ------------------------------------------------------------------------
head(publicschools2016primary)

## ------------------------------------------------------------------------
publicschools2016primary$School_Age <- 2019 - publicschools2016primary$Year_Built

## ------------------------------------------------------------------------
a <- ggplot(publicschools2016primary, aes(x = School_Age))
a + geom_density(aes(color = as.factor(City != "Hamilton"))) + theme(legend.position="bottom")

## ------------------------------------------------------------------------
b <- ggplot(publicschools2016primary, aes(x = School_Age))
b + geom_histogram()

## ------------------------------------------------------------------------
tmap_mode("view")
tm_shape(publicschools2016primary) + tm_dots("School_Age")

